/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.idle_towerdefense;
/*
import java.util.ArrayList;
import java.util.Random;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
*/
/**
 *
 * @author danie
 */
/*public class SortingIT {
    
    public SortingIT() {
    }
    
    @BeforeAll
    public static void setUpClass() {
        ArrayList<Highscore> prev = new ArrayList();
        for(int i = 0; i<10; i++){
        prev.add(new Highscore("banan", (int) Math.round(100*Math.random())));
        }
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of sort method, of class Sorting.
     */
    /*@Test
    public void testSort() {
        System.out.println("sort");
        ArrayList<Highscore> prev = new ArrayList();
        for(int i = 0; i<10; i++){
        prev.add(new Highscore("banan", (int) Math.round(100*Math.random())));
        }
        Sorting instance = new Sorting();
        ArrayList<Highscore> result = instance.sort(prev);
        for(int i = 0; i<9; i++){
            if(result.get(i).score<result.get(i+1).score){
                assertEquals(true, true);
            }
        }
        assertEquals(false, true);
    }
    
}
*/